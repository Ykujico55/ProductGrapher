"""AST node types that exist only on newer Python interpreters."""
import ast


class _UnavailableNode(ast.AST):
    pass


TypeAlias = getattr(ast, "TypeAlias", _UnavailableNode)
TryStar = getattr(ast, "TryStar", _UnavailableNode)
